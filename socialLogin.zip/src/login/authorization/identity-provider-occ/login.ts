export abstract class LoginRequest {
  login?: string;
  email: string;
  firstName?: string;
  lastName?: string;
  siteId?: string;
}
